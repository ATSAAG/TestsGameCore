using Godot;
using System;
using System.Numerics;
using Vector2 = Godot.Vector2;

public partial class walking_enemy : CharacterBody2D
{
	public float speed = 100f;
	private RayCast2D _rayCast;
	private AnimatedSprite2D _sprite;
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();

	public override void _Ready()
	{
		_rayCast = GetNode<RayCast2D>("RayCast2D");
		_sprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	}
	
	public override void _PhysicsProcess(double delta)
	{
		// Add constant speed
		Vector2 velocity = Velocity;

		// Add the gravity
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		velocity.X = speed;
		
		CheckWalls();
		HandleAnimations();
		Velocity = velocity;
		MoveAndSlide();
	}
	public void CheckWalls()
	{
		if (_rayCast.IsColliding())
		{
			speed *= -1;
		}
	}

	public void HandleAnimations()
	{
		if (speed < 0)
		{
			_sprite.FlipH = true;
		}
		else
		{
			_sprite.FlipH = false;
		}
		_sprite.Play("Run");
	}
}
