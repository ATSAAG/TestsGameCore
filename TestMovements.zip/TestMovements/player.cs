using Godot;
using System;

public partial class player : CharacterBody2D
{
	//Setup player attributes.
	public const float Speed = 300.0f;
	public const float JumpVelocity = -400.0f;
	private float _canJump;
	private bool _canFastFall;
	private bool _canDoubleJump;
	private float _IsAnimGoing;
	private AnimatedSprite2D _sprite;

	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();

	public override void _Ready()
	{
		_sprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;
		string anim_spe = "normal";
		
		// Add the gravity, fast fall.
		if (!IsOnFloor())
			if (Input.IsActionJustPressed("down") && _canFastFall)
			{
				anim_spe = "FastFall";
				_canFastFall = false;
			}
			else
			{
				if (!_canFastFall)
				{
					anim_spe = "FastFall";
					velocity.Y += gravity * (float)delta * 10;
				}
				else
				{
					velocity.Y += gravity * (float)delta;
				}
			}

		// Handle Jump and double jump.
		if (IsOnFloor())
		{
			_canJump = 0.2f;
			_canFastFall = true;
		}
		else
		{
			
			if (Input.IsActionJustPressed("jump") && _canDoubleJump)
			{
				anim_spe = "DoubleJump";
			}
			else
			{
				_canJump -= 0.05f;
			}
		}
		
		if (Input.IsActionJustPressed("jump") && _canJump > 0)
			velocity.Y = JumpVelocity;

		// Get the input direction and handle the movement/deceleration.
		Vector2 direction = Input.GetVector("left", "right", "up", "down");
		if (direction != Vector2.Zero)
		{
			velocity.X = direction.X * Speed;
		}
		else
		{
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
		}

		Velocity = velocity;
		
		// Handle animations.
		
		_HandleAnimations(Velocity, anim_spe);
		
		MoveAndSlide();
		
	}
	
	// Handle animations.
	private void _HandleAnimations(Vector2 vitesse, string anim_spe)
	{
		// Handle direction the player is looking.
		if (vitesse.X < 0)
		{
			_sprite.FlipH = true;
		}
		if (vitesse.X > 0)
		{
			_sprite.FlipH = false;
		}
		// Handle basic animations
		if (anim_spe == "normal")
		{
			if (IsOnFloor())
			{ 
				if (vitesse == Vector2.Zero)
				{
					anim_spe = "Idle";
				}
				else
				{
					anim_spe = "Run";
				}
			}
			else
			{
				if (vitesse.Y > 0)
				{
					anim_spe = "Fall";
				}
				else
				{
					anim_spe = "Jump";
				}
			}
		}
		
		// Handle continuous animations.
		if (anim_spe != _sprite.Animation)
		{
			_sprite.Play(anim_spe);
		}
	}
}
